from django.apps import AppConfig


class MindfultraditionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mindfulTradition'
